import React, { Component } from 'react';
import './App.css';
import { FormGroup, ControlLabel, FormControl, HelpBlock, Button, Grid, Row, Col, Pagination } from 'react-bootstrap';

var arr = [
    <h1> Hello world! < /h1>,
    <h2> React is perfect! < /h2>,
];

class App extends Component {
    render() {
        return (
            <div className = "App" >
            <header className = "App-header" >
            <h1 className = "App-title" > LILY Project: NL to SQL < /h1>
            </header>
            <p className = "App-intro" > { this.props.name } To get started, edit < code > src / App.js < /code> and save to reload.  </p>
            <div> { arr } < /div>
            </div>
        );
    }



}


export class FormExample extends React.Component {
    constructor(props, context) {
        super(props, context);
        this.handleChange = this.handleChange.bind(this);

        this.state = {
            value: ''
        };
        this.renderform = this.renderform.bind(this);

    }

    getValidationState() {
        const length = this.state.value.length;
        if (length > 10) return 'success';
        else if (length > 5) return 'warning';
        else if (length > 0) return 'error';
        return null;
    }

    handleChange(e) {
        this.setState({ value: e.target.value });
    }

    renderform(index,arr){
        return (<div>{index} {arr[index]}{ arr[index]}</div>);
    }
    render() {
        let lst = [["select * from hello where a = v", "what are all the hellos"],
            ["select * from ok where b = v", "what are all the oks"]].map(this.renderform);
        return (
            <div >
            <link rel = "stylesheet" href = "https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
            integrity = "sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u"
            crossorigin = "anonymous" / >
            <div className = "App" >
             <div>{lst}</div>
            <header className = "App-header" >
            <h1 className = "App-title" > LILY Project: NL to SQL < /h1>
        </header> <
            /div>

            <
            Grid >
            <
            Row className = "show-grid" >
            <
            Col xs = { 12 } md = { 6 } >

            <
            form id = "input-form" >
            <
            FormGroup controlId = "formBasicText"
            validationState = { this.getValidationState() } >
            <
            ControlLabel > NL / SQL PAIR ID: < /ControlLabel> <
            FormControl type = "text"
            value = { this.state.value } placeholder = "Enter text"
            onChange = { this.handleChange }
            /> <
            FormControl type = "text"
            value = { this.state.value } placeholder = "Enter text"
            onChange = { this.handleChange }
            /> <
            FormControl.Feedback / >
            <
            HelpBlock > fix your natural language here < /HelpBlock> <
            /FormGroup>
            <Button type = "submit" > Submit < /Button>
            <Button type = "delete" > Delete < /Button>
            </form>


            <
            Pagination > < Pagination.First / >
            <
            Pagination.Prev / >
            <Pagination.Item > { 1 } < /Pagination.Item>
            <Pagination.Ellipsis / >

            <Pagination.Item active > { 12 } < /Pagination.Item>
            <Pagination.Ellipsis / >
            <Pagination.Item > { 20 } < /Pagination.Item>
            <Pagination.Next / >
            <Pagination.Last / >
            </Pagination>



            <
            /Col> <
            Col xs = { 6 } md = { 6 } >
            <
            code > Put the picture here! < /code> <
            /Col> <
            /Row> <
            /Grid>




            <
            /div>
        );
    }
}




export default App;